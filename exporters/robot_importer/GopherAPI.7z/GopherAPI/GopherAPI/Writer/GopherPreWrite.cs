﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using GopherAPI.Reader;
using System.Drawing;
using System.Collections;
using GopherAPI.Properties;

namespace GopherAPI.Writer
{
    public class GopherPreWrite
    {
        private static byte[] BitToByte(BitArray bits)
        {
            byte[] ret = new byte[(bits.Length - 1) / 8 + 1];
            bits.CopyTo(ret, 0);
            return ret;
        }
        private static bool[] IntToBits(int n)
        {
            var ret = new bool[5];

            if (n >= 32)
            {
                throw new ArgumentOutOfRangeException("n", "ERROR: Converted Color Value must be between 0 and 31");
            }

            if (n >= 16)
            {
                ret[0] = true;
                n -= 16;
            }
            if (n >= 8)
            {
                ret[1] = true;
                n -= 8;
            }
            if (n >= 4)
            {
                ret[2] = true;
                n -= 4;
            }
            if (n >= 2)
            {
                ret[3] = true;
                n -= 2;
            }
            if (n >= 1)
            {
                ret[4] = true;
                n -= 1;
            }
            return ret;
        }
        public static byte[] ConvertColor(Color ARGB, bool IsDefault)
        {
            BitArray BitArr = new BitArray(16);
            int R = ARGB.R / 8, G = ARGB.G / 8, B = ARGB.B / 8;

            var index = 0;
            foreach (var b in IntToBits(R))
            {
                BitArr.Set(index, b);
                index++;
            }
            foreach (var b in IntToBits(G))
            {
                BitArr.Set(index, b);
                index++;
            }
            foreach (var b in IntToBits(B))
            {
                BitArr.Set(index, b);
                index++;
            }
            BitArr.Set(15, IsDefault);

            return BitToByte(BitArr);
        }

        /// <summary>
        /// Converts thumbnail into a section
        /// </summary>
        /// <param name="thumbnail"></param>
        /// <returns></returns>
        public static Section PreWrite(Bitmap thumbnail)
        {
            ImageConverter converter = new ImageConverter();
            byte[] data = (byte[])converter.ConvertTo(thumbnail, typeof(byte[]));
            return new Section
            {
                ID = SectionType.IMAGE,
                Length = (uint)data.Length,
                Data = data
            };
        }

        public static Section PreWrite(STLAttribute attrib)
        {
            MemoryStream stream = new MemoryStream();
            switch (attrib.Type)
            {
                case AttribType.BOX_COLLIDER:
                    using (BinaryWriter writer = new BinaryWriter(stream))
                    {
                        writer.Write(attrib.AttributeID);
                        writer.Write((ushort)attrib.Type);
                        writer.Write(attrib.xScale);
                    }
                    break;
                case AttribType.SPHERE_COLLIDER:
                    break;
                case AttribType.MESH_COLLIDER:
                    break;
            }
        }
    }
}
