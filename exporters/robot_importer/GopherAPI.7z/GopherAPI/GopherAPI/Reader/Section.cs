﻿using System;
using GopherAPI.Other;

namespace GopherAPI.Reader
{
    public enum SectionType { IMAGE, STL, STL_ATTRIBUTE, JOINT, JOINT_ATTRIBUTE }
    public struct Section
    {
        public SectionType ID;
        public UInt32 Length;
        public byte[] Data;
    }

    public struct RawMesh
    {
        public byte[] Header; //Debug
        public UInt32 MeshID;
        public TransformationMatrix TransMat;
        public UInt32 FacetCount;
        public byte[] Facets;
    }
}
