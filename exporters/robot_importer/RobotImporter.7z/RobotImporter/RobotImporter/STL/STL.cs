﻿using System;
using System.Collections.Generic;

public class STL
{
    UInt32 numMeshes;
    List<Mesh> meshes;

    public STL()
	{
        meshes = new List<Mesh>();
	}
}
