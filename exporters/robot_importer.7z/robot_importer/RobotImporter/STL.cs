﻿using System;

public class STL
{
	public STL()
	{
        UInt32 numMeshes; //number of meshes
	}
}
