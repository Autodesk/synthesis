﻿using System;

public class STLMesh
{
	public STLMesh()
	{
        UInt32 numFacets; //number of facets
        ASCIIEncoding header; //.stl header

        //add 16 4x4 matrix floats

    }
}
