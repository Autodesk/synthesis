﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotImporter.Joints.LinearJoints
{
    class RelayPnuematic : Joint
    {
        public readonly float RelayPort;
        public readonly UInt16 InternalDiameter;
        public readonly UInt16 Pressure;

        public RelayPnuematic(float relayPort, UInt16 internalDiameter, UInt16 pressure, UInt32 id, JointType type, Wheel wheelType, Friction frictionType, InternalDiameter internalDiameterType, Pressure pressureType, Stage stageType,
            UInt32 parentID, UInt32 childID, bool hasJointLimits, UInt16 friction, float[] defVector, float[] relativePoint, float proFreedomFactor, float retroFreedomFactor) :
            base(id, type, wheelType, frictionType, internalDiameterType, pressureType, stageType,
            parentID, childID, hasJointLimits, friction, defVector, relativePoint, proFreedomFactor, retroFreedomFactor)
        {
            RelayPort = relayPort;
            InternalDiameter = internalDiameter;
            Pressure = pressure;
        }
    }
}
