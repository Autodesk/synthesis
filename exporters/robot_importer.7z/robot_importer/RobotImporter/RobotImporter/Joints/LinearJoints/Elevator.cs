﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotImporter.Joints.LinearJoints
{
    class Elevator : Joint
    {
        public readonly bool IsCAN; //false: is PWM
        public readonly float Port;

        public readonly bool HasBrake;
        //if has brake
        public readonly float BrakePort1;
        public readonly float BrakePort2;

        public readonly UInt16 Stages;
        public readonly float InputGear;
        public readonly float OutputGear;

        public Elevator(bool isCAN, float port, bool hasBrake, float brakePort1, float brakePort2, UInt16 stages, float inputGear, float outputGear, UInt32 id, JointType type, Wheel wheelType, Friction frictionType, InternalDiameter internalDiameterType, Pressure pressureType, Stage stageType,
            UInt32 parentID, UInt32 childID, bool hasJointLimits, UInt16 friction, float[] defVector, float[] relativePoint, float proFreedomFactor, float retroFreedomFactor) :
            base(id, type, wheelType, frictionType, internalDiameterType, pressureType, stageType,
            parentID, childID, hasJointLimits, friction, defVector, relativePoint, proFreedomFactor, retroFreedomFactor)
        {
            IsCAN = isCAN;
            Port = port;
            HasBrake = hasBrake;
            BrakePort1 = brakePort1;
            BrakePort2 = brakePort2;
            Stages = stages;
            InputGear = inputGear;
            OutputGear = outputGear;
        }
    }
}
