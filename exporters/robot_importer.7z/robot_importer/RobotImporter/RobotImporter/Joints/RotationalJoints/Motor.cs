﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace RobotImporter.Joints.RotationalJoints
{
    class Motor : Joint
    {
        public readonly bool IsCAN; //false: is PWM port
        public readonly float Port;

        public readonly bool IsDriveWheel;
        public readonly UInt16 Wheel;

        public readonly float InputGear; //ufloat?
        public readonly float OutputGear; //ufloat?

        public Motor (bool isCAN, float port, bool isDriveWheel, UInt16 wheel, float inputGear, float outputGear, UInt32 id, JointType type, Wheel wheelType, Friction frictionType, InternalDiameter internalDiameterType, Pressure pressureType, Stage stageType,
            UInt32 parentID, UInt32 childID, bool hasJointLimits, UInt16 friction, float[] defVector, float[] relativePoint, float proFreedomFactor, float retroFreedomFactor) :
            base(id, type, wheelType, frictionType, internalDiameterType, pressureType, stageType,
            parentID, childID, hasJointLimits, friction, defVector, relativePoint, proFreedomFactor, retroFreedomFactor)
        {
            IsCAN = isCAN;
            Port = port;
            IsDriveWheel = isDriveWheel;
            Wheel = wheel;
            InputGear = inputGear;
            OutputGear = outputGear;
        }
    }
}
