﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotImporter.Joints.RotationalJoints
{
    class Servo : Joint
    {
        public readonly float CANPort;

        public Servo(float canPort, UInt32 id, JointType type, Wheel wheelType, Friction frictionType, InternalDiameter internalDiameterType, Pressure pressureType, Stage stageType,
            UInt32 parentID, UInt32 childID, bool hasJointLimits, UInt16 friction, float[] defVector, float[] relativePoint, float proFreedomFactor, float retroFreedomFactor) :
            base(id, type, wheelType, frictionType, internalDiameterType, pressureType, stageType,
            parentID, childID, hasJointLimits, friction, defVector, relativePoint, proFreedomFactor, retroFreedomFactor)
        {
            CANPort = canPort;
        }
    }
}
