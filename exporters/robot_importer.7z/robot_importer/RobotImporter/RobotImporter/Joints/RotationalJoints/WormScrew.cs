﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotImporter.Joints.RotationalJoints
{
    class WormScrew : Joint
    {
        public readonly bool IsCAN; //false: PWM port
        public readonly float Port;

        public WormScrew (bool isCAN, float port, UInt32 id, JointType type, Wheel wheelType, Friction frictionType, InternalDiameter internalDiameterType, Pressure pressureType, Stage stageType,
            UInt32 parentID, UInt32 childID, bool hasJointLimits, UInt16 friction, float[] defVector, float[] relativePoint, float proFreedomFactor, float retroFreedomFactor) : 
            base (id, type, wheelType, frictionType, internalDiameterType, pressureType, stageType, 
            parentID, childID, hasJointLimits, friction, defVector, relativePoint, proFreedomFactor, retroFreedomFactor)
        {
            IsCAN = isCAN;
            Port = port;
        }
    }
}
