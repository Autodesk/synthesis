﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotImporter.Joints.RotationalJoints
{
    class DualMotor : Joint
    {
        public readonly bool CAN;
        public readonly float Port1;
        public readonly float Port2;

        public readonly bool IsDriveWheel;
        public readonly UInt16 Wheel;
        public readonly float InputGear;
        public readonly float OutputGear;

        public DualMotor(bool can, float port1, float port2, bool isDriveWheel, UInt16 wheel, float inputGear, float outPutGear, UInt32 id, JointType type, Wheel wheelType, Friction frictionType, InternalDiameter internalDiameterType, Pressure pressureType, Stage stageType,
            UInt32 parentID, UInt32 childID, bool hasJointLimits, UInt16 friction, float[] defVector, float[] relativePoint, float proFreedomFactor, float retroFreedomFactor) :
            base(id, type, wheelType, frictionType, internalDiameterType, pressureType, stageType,
            parentID, childID, hasJointLimits, friction, defVector, relativePoint, proFreedomFactor, retroFreedomFactor)
        {
            CAN = can;
            Port1 = port1;
            Port2 = port2;
            IsDriveWheel = isDriveWheel;
            Wheel = wheel;
            InputGear = inputGear;
            OutputGear = outPutGear;
        }
    }
}
