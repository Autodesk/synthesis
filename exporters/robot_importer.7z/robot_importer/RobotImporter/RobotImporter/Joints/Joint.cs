﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RobotImporter.Joints
{
    public enum JointType { ROTATIONAL, LINEAR }
    public enum Wheel { NO_WHEEL, NORMAL, OMNI, MECANMUM };
    public enum Friction { NONE, HIGH, MEDIUM, LOW };
    public enum InternalDiameter { ONE, POINT_FIVE, POINT_TWO_FIVE };
    public enum Pressure { PSI_60, PSI_20, PSI_10 };
    public enum Stage { SINGLE_STAGE_ELEVATOR, CASCADING_STAGE_1, CASCADING_STAGE_2, CONTINUOUS_STAGE_1, CONTINUOUS_STAGE_2 };

    public class Joint
    {
        public readonly UInt32 ID;

        public readonly JointType Type;
        public readonly Wheel WheelType;
        public readonly Friction FrictionType;
        public readonly InternalDiameter InternalDiameterType;
        public readonly Pressure PressureType;
        public readonly Stage StageType;

        public readonly UInt32 ParentID;
        public readonly UInt32 ChildID;
        public readonly bool HasJointLimits;
        //if has Joint Limits
        public readonly UInt16 Friction;

        /// <summary>
        /// Rotational Joint: Vector normal to the plane of rotation
        /// Linear Joint: Vector parallel to the plane of movement
        /// Should be an array of 3 floats with indices 0, 1, 2 corresponding to X, Y, and Z respectively. 
        /// </summary>
        public readonly float[] DefVector;

        /// <summary>
        /// Rotational Joint: Point relative to the parent part
        /// Linear Joint: Point of connection relative to the parent part
        /// Should be an array of 3 floats with indices 0, 1, 2 corresponding to X, Y, and Z respectively. 
        /// </summary>
        public readonly float[] RelativePoint;

        /// <summary>
        /// Rotational Joint: Degree of freedom clockwise
        /// Linear Joint: Centimeters of freedom in the direction of the defining vector
        /// </summary>
        public readonly float ProFreedomFactor;
        /// <summary>
        /// Rotational Joint: Degree of freedom counter-clockwise
        /// Linear Joint: Centimeters of freedom opposite the direction of the defining vector
        /// </summary>
        public readonly float RetroFreedomFactor;

        public Joint(UInt32 id, JointType type, Wheel wheelType, Friction frictionType, InternalDiameter internalDiameterType, Pressure pressureType, Stage stageType, 
            UInt32 parentID, UInt32 childID, bool hasJointLimits, UInt16 friction,
            float[] defVector, float [] relativePoint, float proFreedomFactor, float retroFreedomFactor)
        {
            ID = id;
            Type = type;
            WheelType = wheelType;
            FrictionType = frictionType;
            InternalDiameterType = internalDiameterType;
            PressureType = pressureType;
            StageType = stageType;

            ParentID = parentID;
            ChildID = childID;
            HasJointLimits = hasJointLimits;
            Friction = friction;

            DefVector = defVector;
            RelativePoint = relativePoint;
            ProFreedomFactor = proFreedomFactor;
            RetroFreedomFactor = retroFreedomFactor;
        }
    }
}
